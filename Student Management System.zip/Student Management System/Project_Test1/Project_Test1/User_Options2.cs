﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class User_Options2 : Form
    {
        public User_Options2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            View_Data2 ob = new View_Data2();
            ob.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Class_List ob = new Class_List();
            ob.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            User_Login ob = new User_Login();
            ob.Show();
            this.Hide();
        }

        private void User_Options2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Insert_New_Student_Class2 ob = new Insert_New_Student_Class2();
            ob.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Delete_Data2 ob = new Delete_Data2();
            ob.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Update_Data2 ob = new Update_Data2();
            ob.Show();
            this.Hide();
        }
    }
}
