﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class Update_Data1 : Form
    {
        public Update_Data1()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            User_Options1 ob = new User_Options1();
            ob.Show();
            this.Hide();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";

            if (textBox5.Text == "")
            {
                MessageBox.Show("For update you must search here by Student ID");
                return;
            }

            connect cn = new connect();
            cn.thisConnection.Open();

            OracleCommand thisCommand = cn.thisConnection.CreateCommand();

            thisCommand.CommandText = "Select * from class1 where Student_ID= '" + textBox5.Text + "'";

            OracleDataReader thisReader = thisCommand.ExecuteReader();


            while (thisReader.Read())
            {
                textBox9.Text = thisReader["Student_ID"].ToString();
                textBox2.Text = thisReader["Student_Name"].ToString();
                textBox3.Text = thisReader["Father_Name"].ToString();
                textBox4.Text = thisReader["Mother_Name"].ToString();
                textBox1.Text = thisReader["Address"].ToString();
                textBox6.Text = thisReader["Contact_Number"].ToString();
                textBox7.Text = thisReader["Blood_Group"].ToString();
                textBox8.Text = thisReader["Current_GPA"].ToString();


                try
                {

                }
                catch
                {
                    MessageBox.Show("Successfully updated");
                }
            }

            cn.thisConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox1.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                MessageBox.Show("Fill up empty field");
                return;
            }

            connect sv = new connect();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "update class1 set Address='" + textBox1.Text + "', Contact_Number= '" + textBox6.Text + "', Current_GPA= '" + textBox8.Text + "' where Student_ID = '" + textBox5.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;


            try
            {
                thisCommand.ExecuteNonQuery();
                MessageBox.Show("Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not possible");
                return;
            }

            Update_Data1 ob = new Update_Data1();
            ob.Show();
            this.Hide();
        }

        private void Update_Data1_Load(object sender, EventArgs e)
        {

        }

    }
}
