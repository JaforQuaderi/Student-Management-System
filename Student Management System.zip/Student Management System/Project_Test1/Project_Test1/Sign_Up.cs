﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class Sign_Up : Form
    {
        public Sign_Up()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login_Form ob = new Login_Form();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connect sv = new connect();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "Select username from admin_school where Username= '" + textBox1.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;

            try
            {
                OracleDataReader thisReader = thisCommand.ExecuteReader();

                while (thisReader.Read())
                {
                    string sp = thisReader["Username"].ToString();

                    try
                    {
                        if (sp != "")
                        {
                            MessageBox.Show("This User(Admin) Alaready Exist");
                            sv.thisConnection.Close();
                            return;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Failure");
                    }
                }
                thisReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Fill up all fields");
                return;
            }

            OracleDataAdapter thisAdapter = new OracleDataAdapter("Select * from admin_school", sv.thisConnection);

            OracleCommandBuilder thisBuilder = new OracleCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "admin_school");

            DataRow thisRow = thisDataSet.Tables["admin_school"].NewRow();
            try
            {
                thisRow["Username"] = textBox1.Text;
                thisRow["Password"] = textBox2.Text;
                thisRow["Email"] = textBox3.Text;
                thisRow["Contact_Number"] = textBox4.Text;


                thisDataSet.Tables["admin_school"].Rows.Add(thisRow);

                thisAdapter.Update(thisDataSet, "admin_school");

                MessageBox.Show("New Admin Added Successfully");

                Login_Form ob = new Login_Form();
                ob.Show();
                this.Hide();
            }


            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Fill up all fields");
            }
            sv.thisConnection.Close();
        }
    }
}
