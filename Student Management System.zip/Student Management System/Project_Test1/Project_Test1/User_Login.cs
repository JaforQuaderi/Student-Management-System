﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class User_Login : Form
    {
        public User_Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Please fill up all field");
                return;
            }
            try
            {
                connect cn = new connect();
                cn.thisConnection.Open();
                OracleCommand thisCommand = new OracleCommand();
                thisCommand.Connection = cn.thisConnection;
                thisCommand.CommandText = "SELECT * FROM admin_school WHERE username='" + textBox1.Text + "' AND password='" + textBox2.Text + "'";
                OracleDataReader thisReader = thisCommand.ExecuteReader();
            
                if(thisReader.Read())
                {
                    Class_List oform = new Class_List();
                    oform.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("username or password is wrong");
                }
                cn.thisConnection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login_Form ob = new Login_Form();
            ob.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Admin_Username_Password_Edit ob = new Admin_Username_Password_Edit();
            ob.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
