﻿using System;
using System.Collections.Generic;
using System.Data.OracleClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Test1
{
    class connect
    {
        public OracleConnection thisConnection = new OracleConnection("Data Source=XE; User ID=student; Password=student");
    }
}
