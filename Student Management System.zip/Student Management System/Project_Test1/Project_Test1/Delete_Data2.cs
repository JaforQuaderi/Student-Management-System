﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class Delete_Data2 : Form
    {
        public Delete_Data2()
        {
            InitializeComponent();
        }

        private void Delete_Data2_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            User_Options2 ob = new User_Options2();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";

            if (textBox5.Text == "")
            {
                MessageBox.Show("For delete student information you must search here by Student ID");
                return;
            }

            connect cn = new connect();
            cn.thisConnection.Open();

            OracleCommand thisCommand = cn.thisConnection.CreateCommand();

            thisCommand.CommandText = "Select * from class2 where Student_ID= '" + textBox5.Text + "'";

            OracleDataReader thisReader = thisCommand.ExecuteReader();


            while (thisReader.Read())
            {
                textBox9.Text = thisReader["Student_ID"].ToString();
                textBox2.Text = thisReader["Student_Name"].ToString();
                textBox3.Text = thisReader["Father_Name"].ToString();
                textBox4.Text = thisReader["Mother_Name"].ToString();
                textBox1.Text = thisReader["Address"].ToString();
                textBox6.Text = thisReader["Contact_Number"].ToString();
                textBox7.Text = thisReader["Blood_Group"].ToString();
                textBox8.Text = thisReader["Current_GPA"].ToString();


                try
                {

                }
                catch
                {
                    MessageBox.Show("Successfully updated");
                }
            }

            cn.thisConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connect sv = new connect();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "delete from class2 where Student_ID = '" + textBox5.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;


            try
            {
                thisCommand.ExecuteNonQuery();
                MessageBox.Show("Deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not possible");
                return;
            }

            Delete_Data2 ob = new Delete_Data2();
            ob.Show();
            this.Hide();
        }
    }
}
