﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class View_Data3 : Form
    {
        public View_Data3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User_Options3 ob = new User_Options3();
            ob.Show();
            this.Hide();
        }

        private void cb_searchby_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_searchby.SelectedIndex == 0)
            {
                connect cn = new connect();
                cn.thisConnection.Open();

                OracleCommand thisCommand = new OracleCommand("select Student_ID,Student_Name,Father_Name,Mother_Name,Address,Contact_Number,Blood_Group,Current_GPA from class3 order by Student_ID");

                thisCommand.Connection = cn.thisConnection;
                thisCommand.CommandType = CommandType.Text;

                OracleDataReader thisReader = thisCommand.ExecuteReader();

                listView1.Items.Clear();

                while (thisReader.Read())
                {
                    ListViewItem lsvItem = new ListViewItem();
                    lsvItem.Text = thisReader["Student_ID"].ToString();
                    lsvItem.SubItems.Add(thisReader["Student_Name"].ToString());
                    lsvItem.SubItems.Add(thisReader["Father_Name"].ToString());
                    lsvItem.SubItems.Add(thisReader["Mother_Name"].ToString());
                    lsvItem.SubItems.Add(thisReader["Address"].ToString());
                    lsvItem.SubItems.Add(thisReader["Contact_Number"].ToString());
                    lsvItem.SubItems.Add(thisReader["Blood_Group"].ToString());
                    lsvItem.SubItems.Add(thisReader["Current_GPA"].ToString());

                    listView1.Items.Add(lsvItem);
                }

                cn.thisConnection.Close();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                if (cb_searchby.Text == "" || textBox1.Text == "")
                {
                    MessageBox.Show("Please fill up all requirment");
                    return;
                }

                if (cb_searchby.SelectedIndex != 0)
                {
                    connect cn = new connect();
                    cn.thisConnection.Open();



                    OracleCommand thisCommand = new OracleCommand("select Student_ID,Student_Name,Father_Name,Mother_Name,Address,Contact_Number,Blood_Group,Current_GPA from class3 where " + cb_searchby.Text + " like'%" + textBox1.Text + "%'order by Student_ID");

                    thisCommand.Connection = cn.thisConnection;
                    thisCommand.CommandType = CommandType.Text;

                    OracleDataReader thisReader = thisCommand.ExecuteReader();

                    listView1.Items.Clear();

                    while (thisReader.Read())
                    {
                        ListViewItem lsvItem = new ListViewItem();
                        lsvItem.Text = thisReader["Student_ID"].ToString();
                        lsvItem.SubItems.Add(thisReader["Student_Name"].ToString());
                        lsvItem.SubItems.Add(thisReader["Father_Name"].ToString());
                        lsvItem.SubItems.Add(thisReader["Mother_Name"].ToString());
                        lsvItem.SubItems.Add(thisReader["Address"].ToString());
                        lsvItem.SubItems.Add(thisReader["Contact_Number"].ToString());
                        lsvItem.SubItems.Add(thisReader["Blood_Group"].ToString());
                        lsvItem.SubItems.Add(thisReader["Current_GPA"].ToString());

                        listView1.Items.Add(lsvItem);
                    }

                    cn.thisConnection.Close();
                }

            }
            catch (Exception dx)
            {
                MessageBox.Show(dx.ToString());
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
