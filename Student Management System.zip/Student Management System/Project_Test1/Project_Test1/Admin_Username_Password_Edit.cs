﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class Admin_Username_Password_Edit : Form
    {
        public Admin_Username_Password_Edit()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            User_Login ob = new User_Login();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connect sv = new connect();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "update admin_school set username = '" + textBox2.Text + "',password = '" + textBox3.Text + "' where password= '" + textBox1.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;


            try
            {
                int a = thisCommand.ExecuteNonQuery();

                if (a == 1)
                {
                    MessageBox.Show("Updated Successfully");
                }

                else
                {
                    MessageBox.Show("Error!!! Insert your old password correctly");
                    return;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Not Updated");
            }

            sv.thisConnection.Close();
            this.Close();

            User_Login ob = new User_Login();
            ob.Show();
            this.Hide();



        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
