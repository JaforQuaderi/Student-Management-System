﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Test1
{
    public partial class Insert_New_Student_Class2 : Form
    {
        public Insert_New_Student_Class2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User_Options2 ob = new User_Options2();
            ob.Show();
            this.Hide();
        }

        private void Insert_New_Student_Class2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            connect sv = new connect();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "Select Student_ID from class2 where Student_ID= '" + textBox1.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;

            try
            {
                OracleDataReader thisReader = thisCommand.ExecuteReader();

                while (thisReader.Read())
                {
                    string sp = thisReader["Student_ID"].ToString();

                    try
                    {
                        if (sp != "")
                        {
                            MessageBox.Show("Student ID Alaready Exist");
                            sv.thisConnection.Close();
                            return;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Failure");
                    }
                }
                thisReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                MessageBox.Show("Fill up all fields");
                return;
            }

            OracleDataAdapter thisAdapter = new OracleDataAdapter("Select * from class2", sv.thisConnection);

            OracleCommandBuilder thisBuilder = new OracleCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "class2");

            DataRow thisRow = thisDataSet.Tables["class2"].NewRow();
            try
            {
                thisRow["Student_ID"] = textBox1.Text;
                thisRow["Student_Name"] = textBox2.Text;
                thisRow["Father_Name"] = textBox3.Text;
                thisRow["Mother_Name"] = textBox4.Text;
                thisRow["Address"] = textBox5.Text;
                thisRow["Contact_Number"] = textBox6.Text;
                thisRow["Blood_Group"] = textBox7.Text;
                thisRow["Current_GPA"] = textBox8.Text;


                thisDataSet.Tables["class2"].Rows.Add(thisRow);



                thisAdapter.Update(thisDataSet, "class2");

                MessageBox.Show("Added Successfully");

                Insert_New_Student_Class2 ob = new Insert_New_Student_Class2();
                ob.Show();
                this.Hide();
            }


            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Fill up all fields");
            }
            sv.thisConnection.Close();
        }
    }
}
